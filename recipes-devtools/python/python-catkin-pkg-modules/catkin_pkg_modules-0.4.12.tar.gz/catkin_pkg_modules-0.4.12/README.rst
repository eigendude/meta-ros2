catkin_pkg
----------

Standalone Python library for the `Catkin package system <http://ros.org/wiki/catkin>`_.


Code & tickets
--------------

+------------+--------------------------------------------------------+
| catkin_pkg | http://github.com/ros-infrastructure/catkin_pkg        |
+------------+--------------------------------------------------------+
| Issues     | http://github.com/ros-infrastructure/catkin_pkg/issues |
+------------+--------------------------------------------------------+

Continuous Integration
----------------------

+--------------------------------------------------------------------------+--------------------------------------------------------------------+
| `Build Status <https://travis-ci.org/ros-infrastructure/catkin_pkg>`_.   | .. image:: https://travis-ci.org/ros-infrastructure/catkin_pkg.png |
+--------------------------------------------------------------------------+--------------------------------------------------------------------+
